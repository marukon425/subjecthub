public class Mian {
    public static void main(String[] args) {

        SuperHero sh = new SuperHero(); //スーパーヒーローのコンストラクタ動作がコンソールに表示される
        // Heroクラス
        Hero h = new Hero();
        h.run(); //「ミナトは逃げ出した！」が表示される

        // SuperHeroクラス
        SuperHero sh = new SuperHero();
        sh.run(); // 「ミナトは撤退した」が表示される

    }
}

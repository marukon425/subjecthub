while True:
    print('Hello!')

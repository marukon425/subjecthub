print(print())

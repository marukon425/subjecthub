print(end='!', 'Python')

print(len('Python'))

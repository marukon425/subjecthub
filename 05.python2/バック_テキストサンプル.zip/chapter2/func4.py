print('Python', end='!')

print('Hello', 'Python', end='')

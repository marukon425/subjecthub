print([x for x in range(1, 16)])

while True:
    exec(input())
